
clients = new List<SocketInformation>();
listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
listenSocket.Bind(new IPEndPoint(IPAddress.Any, this.port));
listenThread = new Thread(() =>
{
    while (true)
    {
        listenSocket.Listen(1);
        Socket newClient = listenSocket.Accept();
        lock(clients)
        {
            clients.Add(new SocketInformation(newClient));
        }
    }
});
recieveThread = new Thread(new ThreadStart(recieveData));
