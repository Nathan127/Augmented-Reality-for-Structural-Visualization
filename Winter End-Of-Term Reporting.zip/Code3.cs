try
{
    XmlSerializer serializer = new XmlSerializer(typeof(DataHeader));
    if(!File.Exists(filename))
    {
        Console.WriteLine($"Unable to open file {filename}");
        header = null;
        return false;
    }
    using (var fp = File.OpenRead(filename))
    {
        header = (DataHeader)serializer.Deserialize(fp);
    }
    return true;
}
catch(InvalidProgramException e)
{
    Console.WriteLine($"Unable to parse header file:{e.InnerException}");
    header = null;
    return false;
}