//Called in update to keep updated
void SetColor()
{
    percentage = calculatePercentage(value);
    //Lerp is a built in function that interoplates between 2 values, given a percentage
    lerpedColor = Color.Lerp(minColor, maxColor, percentage);
    GetComponent<Renderer>().material.SetColor("_Color", lerpedColor);
}

//Called in update to keep updated
void SetSize()
{
    percentage = calculatePercentage(value);
    transform.localScale = new Vector3(1, 1, 1) * percentage;
}